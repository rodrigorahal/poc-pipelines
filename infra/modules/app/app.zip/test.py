def run_unit_tests():
    assert True

if __name__ == "__main___":
    run_unit_tests()